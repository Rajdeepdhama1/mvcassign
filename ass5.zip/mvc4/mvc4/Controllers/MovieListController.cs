﻿using Microsoft.AspNetCore.Mvc;
using mvc4.Models;
using System.Collections.Generic;

namespace mvc4.Controllers
{
    public class MovieListController : Controller
    {
        public IActionResult Index()
        {
            List<Movie> movies = MovieData.GetMoviesData();
            return PartialView(movies);
        }
        public IActionResult SearchById(int id)
        {
            var movie = MovieData.GetFilteredMovie(id);
            return PartialView("_FilterMoviePartial",movie);
        }

    }
}